package com.controlDait;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlDaitApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlDaitApplication.class, args);
	}

}
