package com.controlDait;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlDaitApplicationTests {

	@Test
	void contextLoads() {
	}

}
